Travel_Guangdong 源程序包

软件全称：南粤文化入境游 AI 智能伴游系统
版本号：V1.0
打包日期：2026-11-10

包含：
- server-go：Go 生产后端（入口、planner、agent、service、repo、handler、ai）
- web：React 游客网站（源码、构建配置、公共资源）
- miniprogram：微信小程序源码
- cloudfunctions：CloudBase 云函数
- server-java：Spring Boot 参考后端与 Mapper XML
- sql：schema、seed、migrations
- deploy / nginx：systemd、nginx、bootstrap 部署资产
- docs/api/openapi.yaml、docs/agent：接口合同与 Agent 设计
- 根目录 README、docker-compose、package.json 等构建文件

排除：
- node_modules、dist、target、miniprogram_npm、typings、prototype、rules
- .git、.codebuddy、.mimosa、.zcode 等工具元数据
- .env、web/.env.local、deploy/app.env 等真实密钥文件
- 二进制、PDF、DOCX、压缩包、私钥

说明：
软著在线提交的源程序鉴别材料是 03_源代码文档.pdf（前 30 页 + 后 30 页，共 60 页）。
本 zip 是完整工程快照，供备份、代理机构查阅或后续维护使用，不是在线提交文件。
