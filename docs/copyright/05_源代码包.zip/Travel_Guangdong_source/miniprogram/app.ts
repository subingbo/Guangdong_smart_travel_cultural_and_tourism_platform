App<IAppOption>({
  globalData: {},
  onLaunch() {
    if (!wx.cloud) {
      return
    }
    wx.cloud.init({
      env: 'cloud1-3g3ayhyg41b2fe30',
      traceUser: true,
    })
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: () => {
        // 云函数会从调用上下文里取 openid，这里不再兑换 code
      },
    })
  },
})
