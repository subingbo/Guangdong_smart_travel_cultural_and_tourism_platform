import { getLanguage, getTranslations } from '../../../utils/i18n';

Page({
  data: {
    t: {} as any,
    tempImage: '',
    loading: false,
    generatedBlog: null as any
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 'pages/user/travelBlog/index'
      })
    }
    const lang = getLanguage();
    this.setData({ t: getTranslations(lang) });
    wx.setNavigationBarTitle({
      title: lang === 'en' ? 'Travel Blog' : '智慧游记'
    });
  },

  onChooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          tempImage: res.tempFiles[0].tempFilePath
        });
      }
    });
  },

  async onGenerate() {
    if (!this.data.tempImage) return;
    
    this.setData({ loading: true });
    
    try {
      // Image upload is not wired yet, so the temp path is only used for the preview.
      const res = await wx.cloud.callFunction({
        name: 'aiService',
        data: {
          action: 'generate_copy',
          payload: {
            text: "Write a short, engaging travel blog post about a beautiful trip in Guangzhou. Include a title and content.",
            languages: ['en'],
            style: 'Instagram'
          }
        }
      });

      const result = res.result as any;
      if (result.success && result.data && result.data.en) {
        this.setData({
          generatedBlog: {
            // generate_copy returns one string, so the title stays fixed.
            title: "My Amazing Trip",
            content: result.data.en,
            image: this.data.tempImage
          }
        });
        
        wx.showToast({
          title: 'Generated!',
          icon: 'success'
        });
      } else {
        throw new Error('Generation failed');
      }
      
    } catch (error) {
      console.error('Blog generation failed:', error);
      wx.showToast({
        title: 'Failed to generate',
        icon: 'none'
      });
    } finally {
      this.setData({ loading: false });
    }
  }
})
