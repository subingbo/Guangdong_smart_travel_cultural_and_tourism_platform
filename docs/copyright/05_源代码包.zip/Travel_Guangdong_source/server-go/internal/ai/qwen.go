// Package ai holds the external providers: DashScope (Qwen), AMap, Tencent
// Maps and the shared travel-cost estimator.
package ai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/travelgd/server-go/internal/common"
)

type QwenClient struct {
	apiKey  string
	chatURL string
	model   string
	client  *http.Client
}

func NewQwenClient(apiKey, chatURL, model string) *QwenClient {
	if model == "" {
		model = "qwen-plus"
	}
	return &QwenClient{
		apiKey:  apiKey,
		chatURL: chatURL,
		model:   model,
		client:  &http.Client{Timeout: 60 * time.Second},
	}
}

func (q *QwenClient) Enabled() bool { return q.apiKey != "" }

// Model returns the configured model name (qwen-plus unless overridden).
func (q *QwenClient) Model() string { return q.model }

type QwenMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

// ChatDefault sends a completion using the client's default model.
func (q *QwenClient) ChatDefault(ctx context.Context, messages []QwenMessage) (string, error) {
	return q.Chat(ctx, q.model, messages)
}

// Chat sends a completion and returns the assistant message text.
func (q *QwenClient) Chat(ctx context.Context, model string, messages []QwenMessage) (string, error) {
	if !q.Enabled() {
		return "", common.BadGateway("AI provider not configured (DASHSCOPE_API_KEY missing)")
	}
	body, _ := json.Marshal(map[string]interface{}{
		"model":      model,
		"input":      map[string]interface{}{"messages": messages},
		"parameters": map[string]interface{}{"result_format": "message"},
	})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, q.chatURL, bytes.NewReader(body))
	if err != nil {
		return "", common.BadGateway("AI request build failed: " + err.Error())
	}
	req.Header.Set("Authorization", "Bearer "+q.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := q.client.Do(req)
	if err != nil {
		return "", common.BadGateway("AI provider unreachable: " + err.Error())
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", common.BadGateway(fmt.Sprintf("AI provider error: HTTP %d", resp.StatusCode))
	}
	var out struct {
		Output struct {
			Choices []struct {
				Message struct {
					Content string `json:"content"`
				} `json:"message"`
			} `json:"choices"`
		} `json:"output"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil || len(out.Output.Choices) == 0 {
		return "", common.BadGateway("Unexpected AI response shape")
	}
	return out.Output.Choices[0].Message.Content, nil
}

// StripFences removes the ```json fences the model occasionally adds.
func StripFences(text string) string {
	t := strings.ReplaceAll(text, "```json", "")
	return strings.TrimSpace(strings.ReplaceAll(t, "```", ""))
}
