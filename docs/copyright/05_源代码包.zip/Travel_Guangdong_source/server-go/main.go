// Travel Guangdong tourist API. Gin + sqlx; listens on :8081 by default.
package main

import (
	"context"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"

	"github.com/travelgd/server-go/internal/agent"
	"github.com/travelgd/server-go/internal/ai"
	"github.com/travelgd/server-go/internal/auth"
	"github.com/travelgd/server-go/internal/handler"
	"github.com/travelgd/server-go/internal/repo"
	"github.com/travelgd/server-go/internal/service"
)

func env(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func envInt(key string, fallback int) int {
	if v := os.Getenv(key); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			return n
		}
	}
	return fallback
}

func main() {
	dbHost := env("DB_HOST", "localhost")
	dbPort := env("DB_PORT", "3306")
	dbUser := env("DB_USER", "travelgd")
	dbPass := env("DB_PASSWORD", "travelgd")
	dbName := env("DB_NAME", "travel_gd")
	dsn := dbUser + ":" + dbPass + "@tcp(" + dbHost + ":" + dbPort + ")/" + dbName +
		"?parseTime=true&loc=Asia%2FShanghai&charset=utf8mb4"

	db := sqlx.MustConnect("mysql", dsn)
	// The agent runs blocking LLM/AMap calls inside goroutines; keep the
	// database pool as the hard ceiling rather than letting it grow unbounded.
	db.SetMaxOpenConns(envInt("DB_MAX_OPEN_CONNS", 10))
	db.SetMaxIdleConns(envInt("DB_MAX_IDLE_CONNS", 5))
	db.SetConnMaxLifetime(time.Duration(envInt("DB_CONN_MAX_LIFETIME_MINUTES", 30)) * time.Minute)
	db.SetConnMaxIdleTime(5 * time.Minute)

	expireHours, _ := strconv.Atoi(env("JWT_EXPIRE_HOURS", "72"))
	jwtSvc := auth.NewJwtService(
		env("JWT_SECRET", "change-me-to-a-long-random-secret-at-least-32-chars"), expireHours)

	qwen := ai.NewQwenClient(
		env("DASHSCOPE_API_KEY", ""),
		env("AI_CHAT_URL", "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"),
		env("AI_MODEL", "qwen-plus"))

	// Prefer AMap. Tencent stays as a fallback for environments that only have
	// the old key: AMap JS API keys cannot call the Web service API.
	var amapClient *ai.AmapClient
	var weatherClient *ai.WeatherClient
	var mapAPI ai.RouteProvider
	if amapKey := env("AMAP_WEB_KEY", ""); amapKey != "" {
		amapClient = ai.NewAmapClient(
			amapKey,
			env("AMAP_ROUTE_URL", "https://restapi.amap.com/v3/direction"),
			env("AMAP_TRANSIT_CITY", "广州"))
		weatherClient = ai.NewWeatherClient(
			amapKey,
			env("AMAP_WEATHER_URL", "https://restapi.amap.com/v3/weather/weatherInfo"))
		mapAPI = amapClient
	} else {
		mapAPI = ai.NewTencentRouteClient(
			env("TENCENT_MAP_API_KEY", ""),
			env("MAP_ROUTE_URL", "https://apis.map.qq.com/ws/direction/v1"))
	}

	// Repositories
	userRepo := repo.NewUserRepo(db)
	scenicRepo := repo.NewScenicRepo(db)
	placeRepo := repo.NewPlaceRepo(db)
	knowledgeRepo := repo.NewKnowledgeRepo(db)
	favoriteRepo := repo.NewFavoriteRepo(db)
	blogRepo := repo.NewBlogRepo(db)
	routeRepo := repo.NewRouteRepo(db)
	guideRepo := repo.NewGuideRepo(db)
	commentRepo := repo.NewCommentRepo(db)
	followRepo := repo.NewFollowRepo(db)
	notificationRepo := repo.NewNotificationRepo(db)

	// Services
	authSvc := service.NewAuthService(userRepo, jwtSvc)
	notificationSvc := service.NewNotificationService(notificationRepo)
	meSvc := service.NewMeService(authSvc, userRepo, favoriteRepo, routeRepo, blogRepo, followRepo, notificationRepo)
	catalogSvc := service.NewCatalogService(scenicRepo, placeRepo)
	favoriteSvc := service.NewFavoriteService(favoriteRepo, catalogSvc)
	routeSvc := service.NewRouteService(routeRepo, qwen, mapAPI)
	blogSvc := service.NewBlogService(blogRepo, qwen, notificationSvc)
	commentSvc := service.NewCommentService(commentRepo, blogRepo, notificationSvc)
	userSvc := service.NewUserService(userRepo, blogRepo, followRepo, blogSvc, notificationSvc)
	guideSvc := service.NewGuideService(guideRepo, knowledgeRepo, qwen)

	// Handlers
	authH := handler.NewAuthHandler(authSvc)
	meH := handler.NewMeHandler(meSvc)
	catalogH := handler.NewCatalogHandler(catalogSvc)
	favoriteH := handler.NewFavoriteHandler(favoriteSvc)
	routeH := handler.NewRouteHandler(routeSvc)
	blogH := handler.NewBlogHandler(blogSvc)
	commentH := handler.NewCommentHandler(commentSvc)
	userH := handler.NewUserHandler(userSvc)
	notificationH := handler.NewNotificationHandler(notificationSvc)
	uploadH := handler.NewUploadHandler(env("UPLOAD_DIR", "/opt/travel-gd/uploads"))
	guideH := handler.NewGuideHandler(guideSvc)

	// --- AI agent wiring -------------------------------------------------
	// The legacy QwenClient above stays for /guide/chat and /routes/generate.
	// The agent uses the OpenAI-compatible endpoint because it needs tools,
	// streaming deltas and usage accounting.
	agentEnabled := env("AGENT_ENABLED", "true") == "true"
	agentDebug := env("AGENT_DEBUG", "false") == "true"
	openaiClient := ai.NewOpenAIClient(
		env("DASHSCOPE_API_KEY", ""),
		env("AI_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
		env("AI_MODEL", "qwen-plus"),
		env("AI_STREAM", "true") == "true")
	if !openaiClient.Enabled() {
		agentEnabled = false
	}

	agentRepo := repo.NewAgentRepo(db)
	travelSvc := ai.NewTravelService(amapClient, envInt("AGENT_MAP_CONCURRENCY", 8))
	planSvc := service.NewAgentPlanService(agentRepo, guideRepo, placeRepo, routeRepo)
	agentTools := service.NewAgentTools(placeRepo, favoriteRepo, knowledgeRepo, routeRepo, travelSvc, planSvc, weatherClient)
	registry, registryErr := agent.NewRegistry(agentTools.All()...)
	if registryErr != nil {
		log.Fatalf("agent tools: %v", registryErr)
	}
	runner := agent.NewRunner(openaiClient, registry, agent.LoadLimits())

	maxRuns := envInt("AGENT_MAX_CONCURRENT_RUNS", 4)
	queueCapacity := envInt("AGENT_QUEUE_CAPACITY", 16)
	queueTimeout := time.Duration(envInt("AGENT_QUEUE_TIMEOUT_SECONDS", 30)) * time.Second
	var runExecutor agent.Executor
	if env("AGENT_EXECUTOR_MODE", "spawn") == "fixed" {
		runExecutor = agent.NewFixedExecutor(maxRuns, queueCapacity, queueTimeout)
	} else {
		runExecutor = agent.NewSpawnExecutor(maxRuns, queueCapacity, queueTimeout)
	}
	runSvc := service.NewAgentRunService(db, guideRepo, agentRepo, userRepo, runner, runExecutor, service.AgentRunConfig{
		Enabled:            agentEnabled,
		Model:              env("AI_MODEL", "qwen-plus"),
		MaxConcurrentRuns:  maxRuns,
		QueueCapacity:      queueCapacity,
		QueueTimeout:       queueTimeout,
		RunTimeout:         time.Duration(envInt("AGENT_RUN_TIMEOUT_SECONDS", 300)) * time.Second,
		HistoryMessages:    envInt("AGENT_HISTORY_MESSAGES", 12),
		MaxOutputBytes:     envInt("AGENT_MAX_OUTPUT_BYTES", 64*1024),
		RateLimitPerMinute: envInt("AGENT_RATE_LIMIT_PER_MINUTE", 10),
		Debug:              agentDebug,
	})
	recoverCtx, recoverCancel := context.WithTimeout(context.Background(), 10*time.Second)
	if err := runSvc.RecoverInterrupted(recoverCtx); err != nil {
		log.Printf("agent recovery: %v", err)
	}
	recoverCancel()
	shutdownFns = append(shutdownFns, runSvc.Shutdown)
	agentH := handler.NewAgentHandler(runSvc, planSvc, guideSvc, agentDebug)

	r := gin.Default()
	api := r.Group("/api")
	{
		api.POST("/auth/register", authH.Register)
		api.POST("/auth/login", authH.Login)

		api.GET("/scenics", catalogH.ListScenics)
		api.GET("/scenics/:id", catalogH.GetScenic)
		api.GET("/places", catalogH.ListPlaces)
		api.GET("/places/:id", catalogH.GetPlace)

		optional := api.Group("", handler.OptionalAuth(jwtSvc))
		optional.GET("/blogs", blogH.Feed)
		optional.GET("/blogs/:id", blogH.Detail)
		optional.GET("/blogs/:id/comments", commentH.List)
		optional.GET("/users/:id", userH.Profile)
		optional.GET("/users/:id/blogs", userH.Blogs)
		optional.GET("/users/:id/followers", userH.Followers)
		optional.GET("/users/:id/following", userH.Following)

		protected := api.Group("", handler.RequireAuth(jwtSvc))
		protected.GET("/me", meH.Profile)
		protected.PUT("/me", meH.Update)
		protected.GET("/me/stats", meH.Stats)
		protected.GET("/me/blogs", blogH.MyBlogs)
		protected.GET("/favorites", favoriteH.List)
		protected.POST("/favorites", favoriteH.Add)
		protected.DELETE("/favorites/:placeId", favoriteH.Remove)
		protected.POST("/routes/generate", routeH.Generate)
		protected.GET("/routes", routeH.List)
		protected.GET("/routes/:id", routeH.Detail)
		protected.POST("/blogs", blogH.Publish)
		protected.PUT("/blogs/:id", blogH.Update)
		protected.DELETE("/blogs/:id", blogH.Delete)
		protected.POST("/blogs/draft", blogH.Draft)
		protected.POST("/blogs/:id/like", blogH.Like)
		protected.DELETE("/blogs/:id/like", blogH.Unlike)
		protected.POST("/blogs/:id/comments", commentH.Create)
		protected.DELETE("/comments/:id", commentH.Delete)
		protected.POST("/users/:id/follow", userH.Follow)
		protected.DELETE("/users/:id/follow", userH.Unfollow)
		protected.GET("/notifications", notificationH.List)
		protected.GET("/notifications/unread-count", notificationH.UnreadCount)
		protected.POST("/notifications/read", notificationH.MarkRead)
		protected.POST("/notifications/read-all", notificationH.MarkAllRead)
		protected.POST("/upload", uploadH.Upload)
		protected.POST("/guide/chat", guideH.Chat)
		protected.GET("/guide/sessions/:id", guideH.Session)

		protected.POST("/agent/runs", agentH.CreateRun)
		protected.GET("/agent/runs/:id", agentH.GetRun)
		protected.GET("/agent/runs/:id/events", agentH.Stream)
		protected.POST("/agent/runs/:id/cancel", agentH.Cancel)
		protected.POST("/agent/runs/:id/plan/confirm", agentH.ConfirmPlan)
		protected.GET("/agent/conversations", agentH.ListConversations)
		protected.GET("/agent/conversations/:id", agentH.GetConversation)
		if agentDebug {
			protected.GET("/agent/debug/metrics", agentH.Metrics)
		}
	}

	port := env("PORT", "8081")
	// HOST is empty by default (listen on all interfaces) so docker-compose keeps
	// working; production sets HOST=127.0.0.1 to keep the backend behind nginx.
	host := env("HOST", "")

	srv := &http.Server{
		Addr:              host + ":" + port,
		Handler:           r,
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       120 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	errCh := make(chan error, 1)
	go func() {
		log.Printf("travel-gd listening on %s", srv.Addr)
		errCh <- srv.ListenAndServe()
	}()

	select {
	case err := <-errCh:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("server failed: %v", err)
		}
	case <-ctx.Done():
		log.Printf("shutting down")
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	for _, fn := range shutdownFns {
		fn(shutdownCtx)
	}
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Printf("server shutdown: %v", err)
	}
	db.Close()
}

// shutdownFns lets optional subsystems (the agent run manager) drain before
// the HTTP server closes.
var shutdownFns []func(context.Context)
